# 🛍️ TRIVORA — Multi-Brand E-Commerce Clothing Website
### Complete College Project — HTML + CSS + JS + Node.js + MongoDB

---

## 📁 Project Structure

```
trivora/
├── backend/
│   ├── models/          User.js, Product.js, Cart.js, Order.js
│   ├── routes/          auth.js, products.js, cart.js, orders.js
│   ├── middleware/      auth.js (JWT check)
│   ├── server.js        Main server entry point
│   ├── seed.js          Seeds 100 products
│   ├── seed-demo.js     Creates demo accounts (customer / seller / admin)
│   ├── seed-products.js  Seeds 25 clothing products under demo seller
│   └── .env             Config (port, mongo URI, JWT secret)
│
└── frontend/
    ├── css/style.css         Dark theme, responsive, drawer + profile styles
    ├── js/api.js             API helper, auth, toast notifications
    ├── js/wishlist.js        Wishlist system (localStorage + side drawer)
    ├── index.html            Home Page
    ├── products.html         Product Listing + Search + Filters
    ├── product-detail.html   Single Product Page
    ├── cart.html             Shopping Cart
    ├── checkout.html         Checkout + Shipping Form
    ├── order-success.html    Order Confirmation
    ├── wishlist.html         Full Wishlist Page
    ├── profile.html          Profile (5 sections)
    ├── login.html            Login
    └── register.html         Register
```

---

## 🚀 HOW TO RUN

```bash
# Step 1 — Install packages
cd trivora/backend
npm install

# Step 2 — Add 100 products to database (run ONCE)
node seed.js

# Step 3 — Create demo accounts (customer / seller / admin)
node seed-demo.js

# Step 4 — Add 25 real clothing products under demo seller (run ONCE)
node seed-products.js

# Step 5 — Start server
node server.js

# Step 5 — Open browser
# Go to: http://localhost:5000
```

---

## 🔑 Demo Login
- **Email:** demo@trivora.com
- **Password:** demo123

---

## ✅ All Features

### Pages
- 🏠 Home — hero, category grid, featured products
- 🛍️ Products — search, category/subcategory/price filters, sort
- 📄 Product Detail — image, size selector, add to cart, wishlist ♥ button
- 🛒 Cart — quantity controls, order summary, delivery charge
- 💳 Checkout — shipping address form, COD/online payment
- ✅ Order Success — confirmation, order details
- ♥ **Wishlist** — full page + side drawer (NEW)
- 👤 **Profile** — 5 sections (NEW)

### ♥ Wishlist
- Side drawer slides from right — accessible on every page
- Works without login (localStorage)
- Heart ♡/♥ button on every product card and detail page
- Live count badge on navbar
- Add to cart directly from drawer
- Add all items to cart at once
- Smooth animations throughout

### 👤 Profile — 5 Sections
| Tab | Features |
|-----|---------|
| My Account | Edit name, change password, stats |
| My Address | Add/delete/set-default addresses |
| My Orders | Live order history with status |
| FAQs | 12 accordion Q&A items |
| Logout | Confirmation screen |

### 🛒 Shopping
- 100 products: Men (shirts, tees, jeans, jackets), Women (dresses, tops, kurtis, jeans), Kids
- JWT authentication (register/login)
- Cart with quantity controls
- Order placement with shipping form

---

## 🌐 API Endpoints

| Method | Endpoint | Auth |
|--------|----------|------|
| POST | /api/auth/register | No |
| POST | /api/auth/login | No |
| GET | /api/auth/me | Yes |
| GET | /api/products | No |
| GET | /api/products/:id | No |
| GET | /api/cart | Yes |
| POST | /api/cart | Yes |
| PUT | /api/cart/:itemId | Yes |
| DELETE | /api/cart/:itemId | Yes |
| POST | /api/orders | Yes |
| GET | /api/orders | Yes |

---

## ⚠️ Troubleshooting

| Problem | Fix |
|---------|-----|
| MongoDB connection failed | Make sure MongoDB is installed and running |
| Products don't show | Run `node seed.js` |
| Module not found | Run `npm install` in backend folder |
| Port 5000 in use | Change PORT in .env and API_BASE in js/api.js |
| Demo login fails | Run `node seed-demo.js` |

---

Made with ❤️ for **KIRAN's College Project** — Trivora 2025
