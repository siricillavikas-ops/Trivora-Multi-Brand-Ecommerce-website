// ============================================================
// seed.js - Database Seeder
// ============================================================
// Run this file ONCE to set up the database (clears existing products).
// Command: node seed.js
// ============================================================

const mongoose = require('mongoose');
const Product = require('./models/Product');
require('dotenv').config();

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/trivora';

// ---- Helper: Generate consistent Picsum image URL ----
// Each unique seed gives a consistent image every time
const img = (seed) =>
  `https://picsum.photos/seed/${seed}/400/500`;

// ---- 100 Products Data ----
const products = [
  // Products are now added by admins and sellers via the dashboard.
  // This seed file only clears the database and sets up demo users.
  // To add products: login as admin or seller and use the dashboard.
];

// ---- Connect to MongoDB and Seed ----
async function seedDatabase() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('✅ Connected to MongoDB');

    // Remove existing products
    await Product.deleteMany({});
    console.log('🗑️  Cleared existing products');

    // Insert all 100 products
    const inserted = await Product.insertMany(products);
    console.log(`✅ Successfully added ${inserted.length} products to the database!`);

    mongoose.connection.close();
    console.log('🔌 Database connection closed');
    console.log('\n🎉 Seed completed! Now run: node server.js');
  } catch (error) {
    console.error('❌ Seed failed:', error.message);
    process.exit(1);
  }
}

seedDatabase();
