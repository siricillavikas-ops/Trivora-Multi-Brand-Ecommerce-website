// ============================================================
// seed-demo.js - Creates Demo Accounts for all 3 Roles
// ============================================================
// Run: node seed-demo.js
//
//  customer  →  customer@trivora.com  / customer123
//  seller    →  seller@trivora.com    / seller123
//  admin     →  admin@trivora.com     / admin123
// ============================================================

const mongoose = require('mongoose');
const User = require('./models/User');
require('dotenv').config();

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/trivora';

const demoAccounts = [
  { name: 'Demo Customer', email: 'customer@trivora.com', password: 'customer123', role: 'customer' },
  { name: 'Demo Seller',   email: 'seller@trivora.com',   password: 'seller123',   role: 'seller'   },
  { name: 'Admin Trivora', email: 'admin@trivora.com',    password: 'admin123',    role: 'admin'    },
];

async function createDemoAccounts() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('✅ Connected to MongoDB\n');

    for (const account of demoAccounts) {
      await User.deleteOne({ email: account.email });
      await User.create(account);
      console.log(`✅ [${account.role.toUpperCase()}]  ${account.email}  /  ${account.password}`);
    }

    console.log('\n🎉 All demo accounts created! You can now login at http://localhost:5000/login.html');
    mongoose.connection.close();
  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
}

createDemoAccounts();
