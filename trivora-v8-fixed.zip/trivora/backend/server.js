// ============================================================
// server.js - Main Entry Point for Trivora Backend
// ============================================================
// This file sets up the Express server, connects to MongoDB,
// and registers all API routes.
// ============================================================

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
require('dotenv').config(); // Load environment variables from .env file

// ---- Create Express App ----
const app = express();

// ---- Middleware ----
app.use(cors()); // Allow requests from frontend
app.use(express.json()); // Parse incoming JSON requests

// ---- Serve Static Frontend Files ----
// This serves all HTML, CSS, JS files from the 'frontend' folder
app.use(express.static(path.join(__dirname, '../frontend')));

// ---- Import Route Files ----
const authRoutes    = require('./routes/auth');
const productRoutes = require('./routes/products');
const cartRoutes    = require('./routes/cart');
const orderRoutes   = require('./routes/orders');
const sellerRoutes  = require('./routes/seller');
const adminRoutes   = require('./routes/admin');
const uploadRoutes  = require('./routes/upload');

// ---- Serve uploaded product images ----
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ---- Register API Routes ----
app.use('/api/auth',     authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/cart',     cartRoutes);
app.use('/api/orders',   orderRoutes);
app.use('/api/seller',   sellerRoutes);
app.use('/api/admin',    adminRoutes);
app.use('/api/upload',   uploadRoutes);   // image file upload

// ---- Catch-all: Serve index.html for any unknown route ----
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// ---- Connect to MongoDB ----
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/trivora';

mongoose.connect(MONGO_URI)
  .then(() => {
    console.log('✅ Connected to MongoDB successfully!');

    // ---- Start Server ----
    const PORT = process.env.PORT || 5000;
    app.listen(PORT, () => {
      console.log(`🚀 Trivora server is running at http://localhost:${PORT}`);
      console.log(`📌 Open your browser and go to: http://localhost:${PORT}`);
    });
  })
  .catch((error) => {
    console.error('❌ MongoDB connection failed:', error.message);
    process.exit(1);
  });
