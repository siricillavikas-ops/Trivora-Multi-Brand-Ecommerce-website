// ============================================================
// seed-products.js — Seed 25 Clothing Products under Demo Seller
// ============================================================
// Run AFTER seed-demo.js:
//   node seed-demo.js      ← creates seller@trivora.com
//   node seed-products.js  ← adds 25 products under that seller
//
//  10 Men · 10 Women · 5 Kids  — all with real clothing images
// ============================================================

const mongoose = require('mongoose');
const User     = require('./models/User');
const Product  = require('./models/Product');
require('dotenv').config();

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/trivora';

// ============================================================
// PRODUCT DATA
// All images are direct Unsplash source URLs (free, no auth)
// ============================================================

const menProducts = [
  {
    name: 'Classic White Oxford Shirt',
    brand: 'TrovaStyle',
    category: 'men',
    subcategory: 'shirts',
    price: 899,
    originalPrice: 1499,
    stock: 80,
    rating: 4.5,
    reviews: 312,
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: ['White', 'Light Blue'],
    isFeatured: true,
    image: 'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?w=600&q=80',
      'https://images.unsplash.com/photo-1607345366928-199ea26cfe3e?w=600&q=80',
    ],
    description: 'A timeless white Oxford shirt crafted from 100% premium cotton. Features a button-down collar, chest pocket and regular fit silhouette — perfect for office, casual Friday or a smart dinner. Machine washable and wrinkle-resistant fabric keeps you looking sharp all day.',
  },
  {
    name: 'Slim Fit Stretch Chinos',
    brand: 'UrbanThread',
    category: 'men',
    subcategory: 'jeans',
    price: 1299,
    originalPrice: 2199,
    stock: 65,
    rating: 4.3,
    reviews: 228,
    sizes: ['28', '30', '32', '34', '36'],
    colors: ['Khaki', 'Navy', 'Olive'],
    isFeatured: false,
    image: 'https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=600&q=80',
      'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=600&q=80',
    ],
    description: 'Modern slim-fit chinos made with a stretch cotton blend for all-day comfort. A versatile wardrobe staple that goes from desk to dinner effortlessly. Features a flat front, zip fly and two back pockets. Available in three classic tones.',
  },
  {
    name: 'Premium Graphic Tee — Mountain',
    brand: 'WildPeak',
    category: 'men',
    subcategory: 't-shirts',
    price: 499,
    originalPrice: 799,
    stock: 120,
    rating: 4.6,
    reviews: 542,
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Black', 'White', 'Slate'],
    isFeatured: true,
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&q=80',
      'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=600&q=80',
    ],
    description: 'Super-soft 180 GSM combed cotton tee with a bold mountain graphic print on the chest. Relaxed unisex cut with ribbed crew neck and double-needle hem. Pre-shrunk and colourfast — it looks great wash after wash.',
  },
  {
    name: 'Tailored Blazer — Charcoal',
    brand: 'TrovaStyle',
    category: 'men',
    subcategory: 'jackets',
    price: 3499,
    originalPrice: 5499,
    stock: 30,
    rating: 4.7,
    reviews: 189,
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Charcoal', 'Navy'],
    isFeatured: true,
    image: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=600&q=80',
      'https://images.unsplash.com/photo-1594938298603-c8148c4b4357?w=600&q=80',
    ],
    description: 'A sharply tailored single-breasted blazer in a structured charcoal fabric. Notch lapels, two-button closure and a half-canvas construction give it a premium hand feel. Ideal for business meetings, events or elevating a casual weekend look. Dry clean only.',
  },
  {
    name: 'Slim Fit Dark Wash Jeans',
    brand: 'DenimCo',
    category: 'men',
    subcategory: 'jeans',
    price: 1599,
    originalPrice: 2499,
    stock: 90,
    rating: 4.4,
    reviews: 403,
    sizes: ['28', '30', '32', '34', '36', '38'],
    colors: ['Dark Blue', 'Black'],
    isFeatured: false,
    image: 'https://images.unsplash.com/photo-1542272604-787c3835535d?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1542272604-787c3835535d?w=600&q=80',
      'https://images.unsplash.com/photo-1604176354204-9268737828e4?w=600&q=80',
    ],
    description: 'Classic slim-fit jeans in a rich dark wash denim. Made from 98% cotton with 2% elastane for a comfortable stretch. Five-pocket styling with subtle whiskering and clean hems. A go-to pair for any casual outfit.',
  },
  {
    name: 'Lightweight Bomber Jacket',
    brand: 'WildPeak',
    category: 'men',
    subcategory: 'jackets',
    price: 2199,
    originalPrice: 3299,
    stock: 45,
    rating: 4.5,
    reviews: 276,
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Olive', 'Black', 'Navy'],
    isFeatured: false,
    image: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=600&q=80',
      'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=600&q=80',
    ],
    description: 'Lightweight bomber jacket with a smooth nylon shell and subtle quilted lining for extra warmth. Ribbed cuffs, collar and hem for a classic silhouette. Side zip pockets and an inner chest pocket. Perfect for transitional weather.',
  },
  {
    name: 'Mandarin Collar Linen Shirt',
    brand: 'UrbanThread',
    category: 'men',
    subcategory: 'shirts',
    price: 1099,
    originalPrice: 1699,
    stock: 55,
    rating: 4.2,
    reviews: 167,
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['White', 'Beige', 'Sky Blue'],
    isFeatured: false,
    image: 'https://images.unsplash.com/photo-1603252109303-2751441dd157?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1603252109303-2751441dd157?w=600&q=80',
      'https://images.unsplash.com/photo-1588359348347-9bc6cbbb689e?w=600&q=80',
    ],
    description: 'A breezy mandarin collar shirt woven from 100% pure linen — the ultimate fabric for hot days. Slightly relaxed fit with a half-placket front and two chest pockets. Gets softer with every wash. Style with linen trousers or shorts for a complete look.',
  },
  {
    name: 'Essential Black Crew Neck Tee',
    brand: 'TrovaStyle',
    category: 'men',
    subcategory: 't-shirts',
    price: 399,
    originalPrice: 599,
    stock: 200,
    rating: 4.8,
    reviews: 864,
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL'],
    colors: ['Black'],
    isFeatured: true,
    image: 'https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=600&q=80',
      'https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=600&q=80',
    ],
    description: 'The perfect everyday black tee. Made from heavyweight 200 GSM combed cotton with a clean crew neck and a modern semi-fitted silhouette. No fuss, no frills — just exceptional quality that holds its shape and colour wash after wash. A must-have wardrobe essential.',
  },
  {
    name: 'Regular Fit Polo Shirt',
    brand: 'DenimCo',
    category: 'men',
    subcategory: 't-shirts',
    price: 699,
    originalPrice: 999,
    stock: 110,
    rating: 4.3,
    reviews: 334,
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Navy', 'White', 'Forest Green', 'Burgundy'],
    isFeatured: false,
    image: 'https://images.unsplash.com/photo-1571945153237-4929e783af4a?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1571945153237-4929e783af4a?w=600&q=80',
      'https://images.unsplash.com/photo-1620012253295-c15cc3e65df4?w=600&q=80',
    ],
    description: 'A classic piqué polo shirt in a comfortable regular fit. Features a two-button placket, ribbed collar and cuffs, and a subtle side-seam split hem. Made from 100% breathable cotton. Great for smart casual occasions, golf days or weekend brunches.',
  },
  {
    name: 'Quilted Puffer Jacket',
    brand: 'WildPeak',
    category: 'men',
    subcategory: 'jackets',
    price: 2799,
    originalPrice: 4499,
    stock: 38,
    rating: 4.6,
    reviews: 215,
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Black', 'Navy', 'Khaki'],
    isFeatured: false,
    image: 'https://images.unsplash.com/photo-1548126032-079a0fb0099d?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1548126032-079a0fb0099d?w=600&q=80',
      'https://images.unsplash.com/photo-1544022613-e87ca75a784a?w=600&q=80',
    ],
    description: 'Stay warm in style with this lightweight quilted puffer jacket. Filled with premium synthetic insulation that traps heat without bulk. Water-resistant outer shell, zip-through front with storm flap, and two zipped hand pockets. Packable into its own pocket for travel.',
  },
];

const womenProducts = [
  {
    name: 'Floral Wrap Midi Dress',
    brand: 'BlosomWear',
    category: 'women',
    subcategory: 'dresses',
    price: 1799,
    originalPrice: 2799,
    stock: 60,
    rating: 4.7,
    reviews: 487,
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Blue Floral', 'Pink Floral'],
    isFeatured: true,
    image: 'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=600&q=80',
      'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=600&q=80',
    ],
    description: 'A romantic floral wrap dress in a flowing chiffon fabric. Features a V-neckline, adjustable self-tie waist belt and a midi-length hem that hits just below the knee. Fully lined. Beautiful for garden parties, brunches or beach holidays. Hand wash cold.',
  },
  {
    name: 'High Waist Skinny Jeans',
    brand: 'DenimCo',
    category: 'women',
    subcategory: 'jeans',
    price: 1399,
    originalPrice: 2199,
    stock: 85,
    rating: 4.5,
    reviews: 612,
    sizes: ['24', '26', '28', '30', '32'],
    colors: ['Light Blue', 'Black', 'White'],
    isFeatured: true,
    image: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=600&q=80',
      'https://images.unsplash.com/photo-1509551388413-e18d0ac5d495?w=600&q=80',
    ],
    description: 'Figure-flattering high-waist skinny jeans with a buttery-soft stretch denim construction. The elevated waistband elongates your silhouette while providing excellent tummy control. Five-pocket style with zip fly. Pairs perfectly with crop tops, blouses or oversized knitwear.',
  },
  {
    name: 'Printed Anarkali Kurti',
    brand: 'KurtiKraft',
    category: 'women',
    subcategory: 'kurtis',
    price: 999,
    originalPrice: 1599,
    stock: 70,
    rating: 4.6,
    reviews: 391,
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Teal', 'Maroon', 'Royal Blue'],
    isFeatured: true,
    image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&q=80',
      'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?w=600&q=80',
    ],
    description: 'An elegant Anarkali kurti in soft Rayon fabric with a vibrant block print. Features a round neck, 3/4 sleeves and a flowing A-line silhouette that flatters all body types. Pair with churidar or leggings for a complete ethnic look. Machine washable in cold water.',
  },
  {
    name: 'Striped Linen Casual Top',
    brand: 'BlosomWear',
    category: 'women',
    subcategory: 'tops',
    price: 699,
    originalPrice: 1099,
    stock: 95,
    rating: 4.3,
    reviews: 258,
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Navy Stripe', 'Black Stripe'],
    isFeatured: false,
    image: 'https://images.unsplash.com/photo-1485462537746-965f33f7f6a7?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1485462537746-965f33f7f6a7?w=600&q=80',
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&q=80',
    ],
    description: 'A relaxed striped linen top with a breezy feel. Features a boat neckline, dropped shoulders and a slightly cropped hem. The natural linen fabric keeps you cool in warm weather. Tuck into high-waist jeans or wear loose over wide-leg trousers.',
  },
  {
    name: 'Pleated Maxi Skirt',
    brand: 'BlosomWear',
    category: 'women',
    subcategory: 'dresses',
    price: 1199,
    originalPrice: 1899,
    stock: 50,
    rating: 4.4,
    reviews: 198,
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Dusty Rose', 'Sage Green', 'Ivory'],
    isFeatured: false,
    image: 'https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?w=600&q=80',
      'https://images.unsplash.com/photo-1568252542512-9fe8fe9c87bb?w=600&q=80',
    ],
    description: 'A flowing pleated maxi skirt in a soft satin-finish fabric that catches the light beautifully. Features an elasticated waistband for a comfortable fit and full-length hem that grazes the floor. Pairs with a simple camisole for evening wear or a tucked-in blouse for daytime.',
  },
  {
    name: 'Cotton Straight Fit Kurti',
    brand: 'KurtiKraft',
    category: 'women',
    subcategory: 'kurtis',
    price: 799,
    originalPrice: 1199,
    stock: 100,
    rating: 4.5,
    reviews: 476,
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL'],
    colors: ['White', 'Sky Blue', 'Peach', 'Mint'],
    isFeatured: false,
    image: 'https://images.unsplash.com/photo-1626497764746-6dc36546b388?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1626497764746-6dc36546b388?w=600&q=80',
      'https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?w=600&q=80',
    ],
    description: 'An everyday straight-cut kurti in 100% breathable cotton. Lightweight, soft and perfect for warm Indian weather. Features a mandarin collar, subtle embroidery at the neckline and side slits for easy movement. Goes well with palazzo pants, leggings or jeans.',
  },
  {
    name: 'Off-Shoulder Summer Dress',
    brand: 'BlosomWear',
    category: 'women',
    subcategory: 'dresses',
    price: 1499,
    originalPrice: 2299,
    stock: 42,
    rating: 4.6,
    reviews: 321,
    sizes: ['XS', 'S', 'M', 'L'],
    colors: ['Coral', 'White', 'Yellow'],
    isFeatured: true,
    image: 'https://images.unsplash.com/photo-1496747611176-843222e1e57c?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1496747611176-843222e1e57c?w=600&q=80',
      'https://images.unsplash.com/photo-1518611012118-696072aa579a?w=600&q=80',
    ],
    description: 'A breezy off-shoulder mini dress in a soft crinkle cotton fabric. Features an elasticated bardot neckline, puff sleeves and a tiered hem for extra volume. Perfect for beach holidays, summer festivals or warm evenings out. Pair with white sneakers or strappy sandals.',
  },
  {
    name: 'Wide Leg Palazzo Pants',
    brand: 'UrbanThread',
    category: 'women',
    subcategory: 'jeans',
    price: 899,
    originalPrice: 1399,
    stock: 75,
    rating: 4.2,
    reviews: 243,
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Black', 'Camel', 'Rust'],
    isFeatured: false,
    image: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1509631179647-0177331693ae?w=600&q=80',
      'https://images.unsplash.com/photo-1591369822096-ffd140ec948e?w=600&q=80',
    ],
    description: 'Ultra-wide leg palazzo pants in a flowy crepe fabric that drapes beautifully. Features a high elasticated waistband for comfort and a full-length hem. Incredibly versatile — dress up with a fitted blazer and heels, or keep casual with a simple tucked tee.',
  },
  {
    name: 'Embroidered Ethnic Kurti Set',
    brand: 'KurtiKraft',
    category: 'women',
    subcategory: 'kurtis',
    price: 1699,
    originalPrice: 2799,
    stock: 35,
    rating: 4.8,
    reviews: 389,
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Deep Red', 'Bottle Green', 'Indigo'],
    isFeatured: true,
    image: 'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?w=600&q=80',
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&q=80',
    ],
    description: 'A stunning kurti set featuring intricate thread embroidery along the yoke and sleeves. Made from premium chanderi cotton with a smooth, lightweight feel. Set includes a long kurti and matching dupatta. Ideal for festivals, family events or casual ethnic occasions.',
  },
  {
    name: 'Ribbed Fitted Crop Top',
    brand: 'BlosomWear',
    category: 'women',
    subcategory: 'tops',
    price: 499,
    originalPrice: 799,
    stock: 130,
    rating: 4.4,
    reviews: 567,
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Black', 'White', 'Nude', 'Sage'],
    isFeatured: false,
    image: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=600&q=80',
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&q=80',
    ],
    description: 'A stretchy ribbed crop top with a flattering close fit. Made from a soft cotton-spandex blend that holds its shape beautifully. Features a round neck and short sleeves. A wardrobe essential that pairs with literally everything — high waist jeans, skirts, co-ord sets.',
  },
];

const kidsProducts = [
  {
    name: 'Boys Dino Print T-Shirt',
    brand: 'TinyTrends',
    category: 'kids',
    subcategory: 't-shirts',
    price: 349,
    originalPrice: 549,
    stock: 150,
    rating: 4.7,
    reviews: 298,
    sizes: ['2-3Y', '3-4Y', '4-5Y', '5-6Y', '6-7Y', '7-8Y'],
    colors: ['Green', 'Blue'],
    isFeatured: true,
    image: 'https://images.unsplash.com/photo-1519278409-1f56fdda7fe5?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1519278409-1f56fdda7fe5?w=600&q=80',
      'https://images.unsplash.com/photo-1555252333-9f8e92e65df9?w=600&q=80',
    ],
    description: 'A fun dinosaur print T-shirt that kids absolutely love. Made from 100% soft cotton with a comfortable regular fit and ribbed crew neck. The bright dino graphic print is colourfast and fade-resistant. Machine washable. Perfect for school, play dates or family outings.',
  },
  {
    name: 'Girls Twirl Party Dress',
    brand: 'TinyTrends',
    category: 'kids',
    subcategory: 'dresses',
    price: 799,
    originalPrice: 1299,
    stock: 60,
    rating: 4.8,
    reviews: 412,
    sizes: ['2-3Y', '3-4Y', '4-5Y', '5-6Y', '6-7Y', '7-8Y', '8-9Y'],
    colors: ['Pink', 'Lavender', 'Peach'],
    isFeatured: true,
    image: 'https://images.unsplash.com/photo-1476234251651-f353703a034d?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1476234251651-f353703a034d?w=600&q=80',
      'https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?w=600&q=80',
    ],
    description: 'A gorgeous tulle party dress with a satin bodice and a full twirl-worthy skirt. Features a back zip, ribbon sash waist tie and short puffed sleeves. Fully lined for comfort. Perfect for birthdays, weddings, festivals and special family occasions. Spot clean or gentle machine wash.',
  },
  {
    name: 'Kids Jogger Set — Hooded',
    brand: 'KidZone',
    category: 'kids',
    subcategory: 'sets',
    price: 999,
    originalPrice: 1599,
    stock: 80,
    rating: 4.5,
    reviews: 234,
    sizes: ['2-3Y', '3-4Y', '4-5Y', '5-6Y', '6-7Y', '7-8Y', '8-9Y', '9-10Y'],
    colors: ['Grey Marl', 'Navy', 'Burgundy'],
    isFeatured: false,
    image: 'https://images.unsplash.com/photo-1503944583220-79d8926ad5e2?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1503944583220-79d8926ad5e2?w=600&q=80',
      'https://images.unsplash.com/photo-1471286174890-9c112ffca5b4?w=600&q=80',
    ],
    description: 'A cosy two-piece jogger set comprising a hooded sweatshirt and matching jogger pants. Made from a soft brushed fleece interior for warmth and comfort. Features kangaroo pocket on the hoodie and an elasticated waistband with drawstring on the joggers. Great for school, weekends and lounging.',
  },
  {
    name: 'Boys Denim Shorts',
    brand: 'KidZone',
    category: 'kids',
    subcategory: 'shorts',
    price: 449,
    originalPrice: 699,
    stock: 100,
    rating: 4.3,
    reviews: 187,
    sizes: ['2-3Y', '3-4Y', '4-5Y', '5-6Y', '6-7Y', '7-8Y', '8-9Y', '9-10Y'],
    colors: ['Light Blue', 'Dark Blue'],
    isFeatured: false,
    image: 'https://images.unsplash.com/photo-1471286174890-9c112ffca5b4?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1471286174890-9c112ffca5b4?w=600&q=80',
      'https://images.unsplash.com/photo-1519278409-1f56fdda7fe5?w=600&q=80',
    ],
    description: 'Casual denim shorts for active boys. Made from soft stretch denim with an adjustable elasticated waistband for a perfect fit as they grow. Features two front pockets and two back pockets. Perfect for summer days at the park, beach trips and everyday play.',
  },
  {
    name: 'Girls Floral Anarkali Dress',
    brand: 'TinyTrends',
    category: 'kids',
    subcategory: 'dresses',
    price: 699,
    originalPrice: 1099,
    stock: 55,
    rating: 4.6,
    reviews: 302,
    sizes: ['2-3Y', '3-4Y', '4-5Y', '5-6Y', '6-7Y', '7-8Y', '8-9Y'],
    colors: ['Pink', 'Yellow', 'Mint'],
    isFeatured: true,
    image: 'https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?w=600&q=80',
      'https://images.unsplash.com/photo-1476234251651-f353703a034d?w=600&q=80',
    ],
    description: 'A beautiful floral Anarkali dress for little girls. Made from lightweight cotton with a cheerful all-over floral print. Features a round neck, 3/4 sleeves and a flared midi-length skirt with an elasticated waist. Perfect for festivals, family functions and school events.',
  },
];

// ============================================================
// SEED FUNCTION
// ============================================================
async function seedProducts() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('✅ Connected to MongoDB\n');

    // Find the demo seller
    const seller = await User.findOne({ email: 'seller@trivora.com' });
    if (!seller) {
      console.error('❌ Demo seller not found. Run "node seed-demo.js" first.');
      process.exit(1);
    }
    console.log(`👤 Found seller: ${seller.name} (${seller._id})\n`);

    // Remove any previously seeded products for this seller
    const deleted = await Product.deleteMany({ seller: seller._id });
    if (deleted.deletedCount > 0) {
      console.log(`🗑  Removed ${deleted.deletedCount} previously seeded products\n`);
    }

    const allProducts = [
      ...menProducts.map(p => ({ ...p, seller: seller._id, sellerName: seller.name })),
      ...womenProducts.map(p => ({ ...p, seller: seller._id, sellerName: seller.name })),
      ...kidsProducts.map(p => ({ ...p, seller: seller._id, sellerName: seller.name })),
    ];

    const inserted = await Product.insertMany(allProducts);

    const men   = inserted.filter(p => p.category === 'men').length;
    const women = inserted.filter(p => p.category === 'women').length;
    const kids  = inserted.filter(p => p.category === 'kids').length;

    console.log('🎉 Products seeded successfully!\n');
    console.log(`  👔 Men    : ${men} products`);
    console.log(`  👗 Women  : ${women} products`);
    console.log(`  🧒 Kids   : ${kids} products`);
    console.log(`  📦 Total  : ${inserted.length} products\n`);
    console.log('✅ All done! Open http://localhost:5000 to see your products.');

    mongoose.connection.close();
  } catch (error) {
    console.error('❌ Seed error:', error.message);
    process.exit(1);
  }
}

seedProducts();
