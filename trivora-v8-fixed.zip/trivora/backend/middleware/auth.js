// ============================================================
// middleware/auth.js - JWT Authentication Middleware
// ============================================================
// This middleware checks if the user is logged in before
// allowing them to access protected routes (like cart, orders).
// ============================================================

const jwt = require('jsonwebtoken');
const User = require('../models/User');

const protect = async (req, res, next) => {
  let token;

  // Check if token exists in the Authorization header
  // The header looks like: "Bearer eyJhbGciOiJIUzI1NiJ9..."
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    try {
      // Extract the token (remove the "Bearer " prefix)
      token = req.headers.authorization.split(' ')[1];

      // Verify the token and decode it
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'trivora_secret');

      // Find the user in the database (without their password)
      req.user = await User.findById(decoded.id).select('-password');

      // User may have been deleted from DB — treat as unauthorized
      if (!req.user) {
        return res.status(401).json({ message: 'Not authorized, user no longer exists' });
      }

      next(); // Token is valid, continue to the next function
    } catch (error) {
      return res.status(401).json({ message: 'Not authorized, invalid token' });
    }
  }

  if (!token) {
    return res.status(401).json({ message: 'Not authorized, no token provided' });
  }
};

module.exports = { protect };
