// ============================================================
// routes/products.js - Product Routes
// ============================================================
// GET  /api/products          - Get all products (with filters)
// GET  /api/products/:id      - Get single product
// POST /api/products          - Add new product (admin only)
// ============================================================

const express = require('express');
const router = express.Router();
const Product = require('../models/Product');

// ---- GET ALL PRODUCTS: GET /api/products ----
// Supports filters: ?category=men&subcategory=shirts&minPrice=500&maxPrice=2000&search=shirt
router.get('/', async (req, res) => {
  try {
    const { category, subcategory, minPrice, maxPrice, search, featured } = req.query;

    // Build a filter object based on query parameters
    let filter = {};

    if (category) filter.category = category;
    if (subcategory) filter.subcategory = subcategory;
    if (featured) filter.isFeatured = true;

    // Price range filter
    if (minPrice || maxPrice) {
      filter.price = {};
      if (minPrice) filter.price.$gte = Number(minPrice);
      if (maxPrice) filter.price.$lte = Number(maxPrice);
    }

    // Search filter (searches in name and description)
    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: 'i' } },        // 'i' means case-insensitive
        { description: { $regex: search, $options: 'i' } },
        { subcategory: { $regex: search, $options: 'i' } }
      ];
    }

    const products = await Product.find(filter).sort({ createdAt: -1 });

    res.json({
      count: products.length,
      products
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error: ' + error.message });
  }
});

// ---- GET SINGLE PRODUCT: GET /api/products/:id ----
router.get('/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    res.json(product);
  } catch (error) {
    res.status(500).json({ message: 'Server error: ' + error.message });
  }
});

// ---- ADD PRODUCT: POST /api/products ----
router.post('/', async (req, res) => {
  try {
    const product = await Product.create(req.body);
    res.status(201).json({ message: 'Product added successfully!', product });
  } catch (error) {
    res.status(400).json({ message: 'Error adding product: ' + error.message });
  }
});

module.exports = router;
