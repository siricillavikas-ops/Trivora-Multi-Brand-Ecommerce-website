// ============================================================
// routes/admin.js — Admin Dashboard API Routes
// ============================================================
// All routes require login AND role === 'admin'
//
// GET    /api/admin/stats           - site-wide stats
// GET    /api/admin/users           - all users
// DELETE /api/admin/users/:id       - delete a user
// GET    /api/admin/orders          - all orders
// PUT    /api/admin/orders/:id      - update order status
// GET    /api/admin/products        - all products
// DELETE /api/admin/products/:id    - delete any product
// PUT    /api/admin/products/:id    - edit any product
// ============================================================

const express = require('express');
const router  = express.Router();
const User    = require('../models/User');
const Product = require('../models/Product');
const Order   = require('../models/Order');
const { protect } = require('../middleware/auth');

// ---- Middleware: admin only ----
function adminOnly(req, res, next) {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied. Admins only.' });
  }
  next();
}

router.use(protect, adminOnly);

// ---- SITE STATS ----
router.get('/stats', async (req, res) => {
  try {
    const [totalUsers, totalProducts, totalOrders, allOrders] = await Promise.all([
      User.countDocuments(),
      Product.countDocuments(),
      Order.countDocuments(),
      Order.find()
    ]);

    const totalRevenue = allOrders.reduce((sum, o) => sum + (o.totalAmount || 0), 0);
    const recentOrders = await Order.find().sort({ createdAt: -1 }).limit(5);

    res.json({ totalUsers, totalProducts, totalOrders, totalRevenue: Math.round(totalRevenue), recentOrders });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ---- ALL USERS ----
router.get('/users', async (req, res) => {
  try {
    const users = await User.find().select('-password').sort({ createdAt: -1 });
    res.json({ users });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ---- DELETE USER ----
router.delete('/users/:id', async (req, res) => {
  try {
    if (req.params.id === req.user._id.toString()) {
      return res.status(400).json({ message: 'Cannot delete your own admin account' });
    }
    await User.findByIdAndDelete(req.params.id);
    res.json({ message: 'User deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ---- ALL ORDERS ----
router.get('/orders', async (req, res) => {
  try {
    const orders = await Order.find().sort({ createdAt: -1 });
    res.json({ orders });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ---- UPDATE ORDER STATUS ----
router.put('/orders/:id', async (req, res) => {
  try {
    const order = await Order.findByIdAndUpdate(
      req.params.id,
      { status: req.body.status },
      { new: true }
    );
    res.json({ message: 'Order updated', order });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ---- ALL PRODUCTS ----
router.get('/products', async (req, res) => {
  try {
    const products = await Product.find().sort({ createdAt: -1 });
    res.json({ products });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ---- ADD PRODUCT (admin) ----
router.post('/products', async (req, res) => {
  try {
    const product = await Product.create({
      ...req.body,
      seller: null,
      sellerName: req.user.name + ' (Admin)'
    });
    res.status(201).json({ message: 'Product added!', product });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// ---- DELETE ANY PRODUCT ----
router.delete('/products/:id', async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ message: 'Product deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ---- UPDATE ANY PRODUCT ----
router.put('/products/:id', async (req, res) => {
  try {
    const product = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ message: 'Product updated', product });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
