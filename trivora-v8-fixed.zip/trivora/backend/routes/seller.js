// ============================================================
// routes/seller.js — Seller Dashboard API Routes
// ============================================================
// All routes require login AND role === 'seller'
//
// GET  /api/seller/stats          - dashboard stats
// GET  /api/seller/products       - this seller's products
// POST /api/seller/products       - add a new product
// PUT  /api/seller/products/:id   - update a product
// DELETE /api/seller/products/:id - delete a product
// GET  /api/seller/orders         - orders containing seller's products
// ============================================================

const express  = require('express');
const router   = express.Router();
const Product  = require('../models/Product');
const Order    = require('../models/Order');
const { protect } = require('../middleware/auth');

// ---- Middleware: must be logged in as seller ----
function sellerOnly(req, res, next) {
  if (req.user.role !== 'seller' && req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied. Sellers only.' });
  }
  next();
}

router.use(protect, sellerOnly);

// ---- GET STATS ----
router.get('/stats', async (req, res) => {
  try {
    const products = await Product.find({ seller: req.user._id });
    const productIds = products.map(p => p._id);

    // Count orders that contain this seller's products
    const orders = await Order.find({
      'items.product': { $in: productIds }
    });

    const totalRevenue = orders.reduce((sum, order) => {
      const sellerItems = order.items.filter(item =>
        productIds.some(id => id.toString() === item.product?.toString())
      );
      return sum + sellerItems.reduce((s, i) => s + i.price * i.quantity, 0);
    }, 0);

    res.json({
      totalProducts: products.length,
      totalOrders: orders.length,
      totalRevenue: Math.round(totalRevenue),
      recentOrders: orders.slice(0, 5)
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ---- GET MY PRODUCTS ----
router.get('/products', async (req, res) => {
  try {
    const products = await Product.find({ seller: req.user._id }).sort({ createdAt: -1 });
    res.json({ products });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ---- ADD PRODUCT ----
router.post('/products', async (req, res) => {
  try {
    const product = await Product.create({
      ...req.body,
      seller: req.user._id,
      sellerName: req.user.name
    });
    res.status(201).json({ message: 'Product added!', product });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// ---- UPDATE PRODUCT ----
router.put('/products/:id', async (req, res) => {
  try {
    const product = await Product.findOne({ _id: req.params.id, seller: req.user._id });
    if (!product) return res.status(404).json({ message: 'Product not found or not yours' });

    Object.assign(product, req.body);
    await product.save();
    res.json({ message: 'Product updated!', product });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ---- DELETE PRODUCT ----
router.delete('/products/:id', async (req, res) => {
  try {
    const product = await Product.findOneAndDelete({ _id: req.params.id, seller: req.user._id });
    if (!product) return res.status(404).json({ message: 'Product not found or not yours' });
    res.json({ message: 'Product deleted!' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ---- GET SELLER'S ORDERS ----
router.get('/orders', async (req, res) => {
  try {
    const myProducts = await Product.find({ seller: req.user._id });
    const myProductIds = myProducts.map(p => p._id.toString());

    const allOrders = await Order.find({
      'items.product': { $in: myProductIds }
    }).sort({ createdAt: -1 });

    // Filter items to only show this seller's items
    const sellerOrders = allOrders.map(order => ({
      ...order.toObject(),
      items: order.items.filter(item =>
        myProductIds.includes(item.product?.toString())
      )
    }));

    res.json({ orders: sellerOrders });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
