// ============================================================
// routes/orders.js - Order Routes
// ============================================================
// POST /api/orders       - Place a new order
// GET  /api/orders       - Get user's order history
// GET  /api/orders/:id   - Get single order details
// ============================================================

const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const Cart = require('../models/Cart');
const { protect } = require('../middleware/auth');

// All order routes require login
router.use(protect);

// ---- PLACE ORDER: POST /api/orders ----
router.post('/', async (req, res) => {
  const { shippingAddress, paymentMethod } = req.body;

  try {
    // Get the user's cart
    const cart = await Cart.findOne({ user: req.user._id }).populate('items.product');

    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ message: 'Your cart is empty' });
    }

    // Calculate the total amount
    const totalAmount = cart.items.reduce((total, item) => {
      return total + (item.product.price * item.quantity);
    }, 0);

    // Create order items from cart items
    const orderItems = cart.items.map(item => ({
      product: item.product._id,
      name: item.product.name,
      price: item.product.price,
      quantity: item.quantity,
      size: item.size,
      image: item.product.image
    }));

    // Create the order
    const order = await Order.create({
      user: req.user._id,
      items: orderItems,
      totalAmount,
      shippingAddress,
      paymentMethod: paymentMethod || 'cod'
    });

    // Clear the cart after placing order
    cart.items = [];
    await cart.save();

    res.status(201).json({
      message: 'Order placed successfully! 🎉',
      order
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error: ' + error.message });
  }
});

// ---- GET MY ORDERS: GET /api/orders ----
router.get('/', async (req, res) => {
  try {
    const orders = await Order.find({ user: req.user._id }).sort({ createdAt: -1 });
    res.json({ orders });
  } catch (error) {
    res.status(500).json({ message: 'Server error: ' + error.message });
  }
});

// ---- GET SINGLE ORDER: GET /api/orders/:id ----
router.get('/:id', async (req, res) => {
  try {
    const order = await Order.findOne({
      _id: req.params.id,
      user: req.user._id
    });

    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    res.json(order);
  } catch (error) {
    res.status(500).json({ message: 'Server error: ' + error.message });
  }
});

module.exports = router;
