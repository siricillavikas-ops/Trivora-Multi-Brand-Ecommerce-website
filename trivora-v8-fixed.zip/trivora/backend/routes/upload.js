// ============================================================
// routes/upload.js — Image Upload Route
// ============================================================
// POST /api/upload/image  — upload .jpg or .png, returns URL
// Only accessible by seller or admin (logged-in)
// ============================================================

const express  = require('express');
const router   = express.Router();
const multer   = require('multer');
const path     = require('path');
const fs       = require('fs');
const { protect } = require('../middleware/auth');

// ---- Make sure uploads folder exists ----
const uploadDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

// ---- Multer storage config ----
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    // Unique filename: timestamp + original name (sanitised)
    const ext  = path.extname(file.originalname).toLowerCase();
    const base = path.basename(file.originalname, ext).replace(/[^a-z0-9]/gi, '-').toLowerCase();
    cb(null, `${Date.now()}-${base}${ext}`);
  }
});

// ---- Accept only jpg / jpeg / png ----
const fileFilter = (req, file, cb) => {
  const allowed = ['.jpg', '.jpeg', '.png'];
  const ext = path.extname(file.originalname).toLowerCase();
  if (allowed.includes(ext)) {
    cb(null, true);
  } else {
    cb(new Error('Only .jpg and .png files are allowed'), false);
  }
};

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 5 * 1024 * 1024 } // 5 MB max
});

// ---- POST /api/upload/image (single) ----
router.post('/image', protect, upload.single('image'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: 'No file uploaded or invalid file type.' });
  }
  const protocol = req.protocol;
  const host = req.get('host');
  const imageUrl = `${protocol}://${host}/uploads/${req.file.filename}`;
  res.json({ message: 'Upload successful', imageUrl, filename: req.file.filename });
});

// ---- POST /api/upload/images (multiple, up to 5) ----
router.post('/images', protect, upload.array('images', 5), (req, res) => {
  if (!req.files || req.files.length === 0) {
    return res.status(400).json({ message: 'No files uploaded or invalid file types.' });
  }
  const protocol = req.protocol;
  const host = req.get('host');
  const imageUrls = req.files.map(f => `${protocol}://${host}/uploads/${f.filename}`);
  res.json({ message: 'Upload successful', imageUrls });
});

// ---- Error handler for multer errors ----
router.use((err, req, res, next) => {
  if (err instanceof multer.MulterError || err.message) {
    return res.status(400).json({ message: err.message });
  }
  next(err);
});

module.exports = router;
