// ============================================================
// routes/cart.js - Cart Routes
// ============================================================
// GET    /api/cart          - Get user's cart
// POST   /api/cart          - Add item to cart
// PUT    /api/cart/:itemId  - Update item quantity
// DELETE /api/cart/:itemId  - Remove item from cart
// DELETE /api/cart          - Clear entire cart
// ============================================================

const express = require('express');
const router = express.Router();
const Cart = require('../models/Cart');
const Product = require('../models/Product');
const { protect } = require('../middleware/auth');

// All cart routes are protected - user must be logged in
router.use(protect);

// ---- GET CART: GET /api/cart ----
router.get('/', async (req, res) => {
  try {
    // Find cart and fill in product details (populate)
    let cart = await Cart.findOne({ user: req.user._id }).populate('items.product');

    if (!cart) {
      // Create empty cart if user doesn't have one
      cart = await Cart.create({ user: req.user._id, items: [] });
    }

    res.json(cart);
  } catch (error) {
    res.status(500).json({ message: 'Server error: ' + error.message });
  }
});

// ---- ADD TO CART: POST /api/cart ----
router.post('/', async (req, res) => {
  const { productId, quantity = 1, size = 'M' } = req.body;

  try {
    // Check if the product exists
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    // Find user's cart or create a new one
    let cart = await Cart.findOne({ user: req.user._id });
    if (!cart) {
      cart = new Cart({ user: req.user._id, items: [] });
    }

    // Check if this product is already in the cart
    const existingItem = cart.items.find(
      item => item.product.toString() === productId && item.size === size
    );

    if (existingItem) {
      // If already in cart, just increase the quantity
      existingItem.quantity += quantity;
    } else {
      // Add as a new item
      cart.items.push({ product: productId, quantity, size });
    }

    await cart.save();
    await cart.populate('items.product');

    res.json({ message: 'Item added to cart!', cart });
  } catch (error) {
    res.status(500).json({ message: 'Server error: ' + error.message });
  }
});

// ---- UPDATE QUANTITY: PUT /api/cart/:itemId ----
router.put('/:itemId', async (req, res) => {
  const { quantity } = req.body;

  try {
    const cart = await Cart.findOne({ user: req.user._id });
    if (!cart) return res.status(404).json({ message: 'Cart not found' });

    // Find the specific item in the cart
    const item = cart.items.id(req.params.itemId);
    if (!item) return res.status(404).json({ message: 'Item not found in cart' });

    if (quantity <= 0) {
      // Remove item if quantity is 0 or less
      item.deleteOne();
    } else {
      item.quantity = quantity;
    }

    await cart.save();
    await cart.populate('items.product');

    res.json({ message: 'Cart updated!', cart });
  } catch (error) {
    res.status(500).json({ message: 'Server error: ' + error.message });
  }
});

// ---- REMOVE ITEM: DELETE /api/cart/:itemId ----
router.delete('/:itemId', async (req, res) => {
  try {
    const cart = await Cart.findOne({ user: req.user._id });
    if (!cart) return res.status(404).json({ message: 'Cart not found' });

    cart.items = cart.items.filter(item => item._id.toString() !== req.params.itemId);

    await cart.save();
    await cart.populate('items.product');

    res.json({ message: 'Item removed from cart!', cart });
  } catch (error) {
    res.status(500).json({ message: 'Server error: ' + error.message });
  }
});

// ---- CLEAR CART: DELETE /api/cart ----
router.delete('/', async (req, res) => {
  try {
    await Cart.findOneAndUpdate(
      { user: req.user._id },
      { items: [] }
    );
    res.json({ message: 'Cart cleared!' });
  } catch (error) {
    res.status(500).json({ message: 'Server error: ' + error.message });
  }
});

module.exports = router;
