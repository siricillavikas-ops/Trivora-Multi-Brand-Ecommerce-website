// ============================================================
// models/User.js - MongoDB User Schema
// ============================================================
// This defines what a "User" looks like in our database.
// Each user has a name, email, password, and role.
// ============================================================

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs'); // For password hashing

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Name is required'],
    trim: true
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,        // No two users can have the same email
    lowercase: true,
    trim: true
  },
  password: {
    type: String,
    required: [true, 'Password is required'],
    minlength: 6
  },
  role: {
    type: String,
    enum: ['customer', 'seller', 'admin'], // Only these 3 roles allowed
    default: 'customer'
  },
  address: {
    street: String,
    city: String,
    state: String,
    pincode: String
  }
}, {
  timestamps: true // Automatically adds createdAt and updatedAt fields
});

// ---- Hash password before saving to database ----
// This runs automatically every time a user is created or password is changed
userSchema.pre('save', async function (next) {
  // Only hash if password was modified
  if (!this.isModified('password')) return next();

  // Generate a salt (random data) and hash the password
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// ---- Method to check if entered password matches the hashed one ----
userSchema.methods.comparePassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

module.exports = mongoose.model('User', userSchema);
