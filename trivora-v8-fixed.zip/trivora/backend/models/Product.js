// ============================================================
// models/Product.js - MongoDB Product Schema
// ============================================================
// This defines what a "Product" looks like in our database.
// ============================================================

const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Product name is required'],
    trim: true
  },
  price: {
    type: Number,
    required: [true, 'Price is required'],
    min: [0, 'Price cannot be negative']
  },
  originalPrice: {
    type: Number, // The old price (for showing discount)
    default: null
  },
  category: {
    type: String,
    required: true,
    enum: ['men', 'women', 'kids'] // Only these 3 categories
  },
  subcategory: {
    type: String,
    required: true
    // Examples: 'shirts', 't-shirts', 'jeans', 'dresses', 'kurtis', etc.
  },
  description: {
    type: String,
    required: true
  },
  image: {
    type: String,  // Primary/first image URL (kept for backward compatibility)
    required: true
  },
  images: {
    type: [String],  // All product images (including primary)
    default: []
  },
  brand: {
    type: String,
    default: 'Trivora'
  },
  sizes: {
    type: [String],
    default: ['S', 'M', 'L', 'XL', 'XXL'] // Available sizes
  },
  colors: {
    type: [String],
    default: ['Default']
  },
  stock: {
    type: Number,
    default: 50
  },
  rating: {
    type: Number,
    default: 4.0,
    min: 0,
    max: 5
  },
  reviews: {
    type: Number,
    default: 0
  },
  isFeatured: {
    type: Boolean,
    default: false
  },
  seller: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null   // null means seeded/admin product
  },
  sellerName: {
    type: String,
    default: 'Trivora Official'
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Product', productSchema);
