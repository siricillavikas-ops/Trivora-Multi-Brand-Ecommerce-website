// ============================================================
// models/Cart.js - MongoDB Cart Schema
// ============================================================
// Each user has ONE cart that contains multiple items.
// ============================================================

const mongoose = require('mongoose');

// Each item in the cart
const cartItemSchema = new mongoose.Schema({
  product: {
    type: mongoose.Schema.Types.ObjectId, // Reference to the Product
    ref: 'Product',
    required: true
  },
  quantity: {
    type: Number,
    required: true,
    min: 1,
    default: 1
  },
  size: {
    type: String,
    default: 'M'
  }
});

// The main Cart (belongs to one user)
const cartSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId, // Reference to the User
    ref: 'User',
    required: true,
    unique: true // Each user can only have ONE cart
  },
  items: [cartItemSchema] // An array of cart items
}, {
  timestamps: true
});

module.exports = mongoose.model('Cart', cartSchema);
