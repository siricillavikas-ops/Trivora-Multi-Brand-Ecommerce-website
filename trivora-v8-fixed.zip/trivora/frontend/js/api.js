// ============================================================
// js/api.js - API Helper Functions
// ============================================================
// This file handles all communication with the backend server.
// All pages import this file to make API calls.
// ============================================================

// Base URL for all API calls
const API_BASE = 'http://localhost:5000/api';

// ---- Get auth token from localStorage ----
function getToken() {
  return localStorage.getItem('trivora_token');
}

// ---- Get current user info from localStorage ----
function getUser() {
  const user = localStorage.getItem('trivora_user');
  return user ? JSON.parse(user) : null;
}

// ---- Check if user is logged in ----
function isLoggedIn() {
  return !!getToken();
}

// ---- Logout - clear stored data ----
function logout() {
  localStorage.removeItem('trivora_token');
  localStorage.removeItem('trivora_user');
  updateNavAuthState();
  window.location.href = 'login.html';
}

// ---- Generic API Request Function ----
// Method: 'GET', 'POST', 'PUT', 'DELETE'
// Body: data to send (for POST/PUT)
// requiresAuth: whether to include JWT token
async function apiRequest(endpoint, method = 'GET', body = null, requiresAuth = false) {
  const headers = { 'Content-Type': 'application/json' };

  // Add auth token if required
  if (requiresAuth) {
    const token = getToken();
    if (!token) {
      showToast('Please login to continue', 'error');
      window.location.href = 'login.html';
      return null;
    }
    headers['Authorization'] = `Bearer ${token}`;
  }

  const options = { method, headers };
  if (body) options.body = JSON.stringify(body);

  try {
    const res = await fetch(`${API_BASE}${endpoint}`, options);
    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.message || 'Something went wrong');
    }
    return data;
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
}

// ---- Shortcut API functions ----
const api = {
  // Products
  getProducts: (params = '') => apiRequest(`/products${params}`),
  getProduct: (id) => apiRequest(`/products/${id}`),

  // Auth
  register: (data) => apiRequest('/auth/register', 'POST', data),
  login: (data) => apiRequest('/auth/login', 'POST', data),
  getMe: () => apiRequest('/auth/me', 'GET', null, true),

  // Cart
  getCart: () => apiRequest('/cart', 'GET', null, true),
  addToCart: (data) => apiRequest('/cart', 'POST', data, true),
  updateCart: (itemId, data) => apiRequest(`/cart/${itemId}`, 'PUT', data, true),
  removeFromCart: (itemId) => apiRequest(`/cart/${itemId}`, 'DELETE', null, true),
  clearCart: () => apiRequest('/cart', 'DELETE', null, true),

  // Orders
  placeOrder: (data) => apiRequest('/orders', 'POST', data, true),
  getOrders: () => apiRequest('/orders', 'GET', null, true),
};

// ============================================================
// TOAST NOTIFICATION SYSTEM
// ============================================================
function showToast(message, type = 'success') {
  // Create or get toast container
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const icon = type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️';

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span class="toast-icon">${icon}</span> ${message}`;
  container.appendChild(toast);

  // Remove toast after 3.5 seconds
  setTimeout(() => {
    toast.style.animation = 'slideOut 0.3s ease forwards';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// ============================================================
// NAVBAR STATE UPDATE
// ============================================================
function updateNavAuthState() {
  const user = getUser();
  const cartIcon = document.getElementById('nav-cart-icon');
  const loginBtn = document.getElementById('nav-login-btn');
  const userMenu = document.getElementById('nav-user-menu');
  const userName = document.getElementById('nav-user-name');

  if (user && isLoggedIn()) {
    if (loginBtn) loginBtn.style.display = 'none';
    if (userMenu) userMenu.style.display = 'flex';
    if (userName) userName.textContent = user.name.split(' ')[0]; // First name only
  } else {
    if (loginBtn) loginBtn.style.display = 'block';
    if (userMenu) userMenu.style.display = 'none';
  }
}

// ============================================================
// FORMAT PRICE (adds ₹ and commas)
// ============================================================
function formatPrice(amount) {
  return '₹' + amount.toLocaleString('en-IN');
}

// ============================================================
// CALCULATE DISCOUNT PERCENTAGE
// ============================================================
function calcDiscount(original, current) {
  if (!original || original <= current) return 0;
  return Math.round(((original - current) / original) * 100);
}

// ============================================================
// GENERATE STAR RATING HTML
// ============================================================
function renderStars(rating) {
  const full = Math.floor(rating);
  const half = rating % 1 >= 0.5 ? 1 : 0;
  const empty = 5 - full - half;
  return '★'.repeat(full) + (half ? '½' : '') + '☆'.repeat(empty);
}

// ============================================================
// INITIALIZE NAVBAR (runs on every page)
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
  updateNavAuthState();
  updateCartBadge();

  // Hamburger menu toggle
  const hamburger = document.getElementById('hamburger');
  const mobileMenu = document.getElementById('mobile-menu');
  if (hamburger && mobileMenu) {
    hamburger.addEventListener('click', () => {
      mobileMenu.classList.toggle('open');
    });
  }
});

// ---- Update cart count badge ----
async function updateCartBadge() {
  if (!isLoggedIn()) return;

  const badge = document.getElementById('cart-badge');
  if (!badge) return;

  try {
    const data = await api.getCart();
    const count = data.items ? data.items.length : 0;
    badge.textContent = count;
    badge.style.display = count > 0 ? 'flex' : 'none';
  } catch (e) {
    badge.style.display = 'none';
  }
}
