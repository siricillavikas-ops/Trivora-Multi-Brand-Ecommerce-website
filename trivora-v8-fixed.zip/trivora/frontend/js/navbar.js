// ============================================================
// js/navbar.js  — Shared Navbar Builder
// ============================================================
// Call buildNavbar() in every page's <body>.
// Renders navbar with: Logo | Nav Links | Search | Icons | User
// NO Logout button in navbar — logout is only in Profile page.
// ============================================================

function buildNavbar(activePage) {
  const isHome     = activePage === 'home';
  const isMen      = activePage === 'men';
  const isWomen    = activePage === 'women';
  const isKids     = activePage === 'kids';
  const isProducts = activePage === 'products';

  return `
  <nav class="navbar" id="main-navbar">
    <a href="index.html" class="nav-logo">TRIVORA</a>

    <ul class="nav-links">
      <li><a href="index.html"  ${isHome     ? 'style="color:var(--accent)"' : ''}>Home</a></li>
      <li><a href="products.html?category=men"    ${isMen    ? 'style="color:var(--accent)"' : ''}>Men</a></li>
      <li><a href="products.html?category=women"  ${isWomen  ? 'style="color:var(--accent)"' : ''}>Women</a></li>
      <li><a href="products.html?category=kids"   ${isKids   ? 'style="color:var(--accent)"' : ''}>Kids</a></li>
      <li><a href="products.html" ${isProducts ? 'style="color:var(--accent)"' : ''}>All Products</a></li>
    </ul>

    <!-- Search Bar -->
    <form class="nav-search-form" id="nav-search-form" onsubmit="navSearch(event)">
      <input type="text" class="nav-search-input" id="nav-search-input"
             placeholder="Search products…" autocomplete="off">
      <button type="submit" class="nav-search-btn" title="Search">🔍</button>
    </form>

    <div class="nav-icons">
      <!-- Wishlist -->
      <button class="nav-icon-btn" onclick="openWishlistDrawer()" title="Wishlist" style="position:relative;">
        ♥<span class="wishlist-nav-count" style="display:none;">0</span>
      </button>
      <!-- Cart -->
      <a href="cart.html" class="nav-icon-btn" title="Cart" style="position:relative;">
        🛒<span class="cart-count" id="cart-badge" style="display:none;">0</span>
      </a>
      <!-- Guest: Login button -->
      <a href="login.html" id="nav-login-btn"><button class="btn-login-nav">Login</button></a>
      <!-- Logged in: Profile icon only — NO Logout here -->
      <div id="nav-user-menu" style="display:none;align-items:center;gap:0.6rem;">
        <span style="color:var(--gray-light);font-size:0.82rem;">Hi, <strong id="nav-user-name" style="color:var(--accent)"></strong></span>
        <a href="profile.html" title="My Profile"
           style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,var(--accent),#005588);display:flex;align-items:center;justify-content:center;font-size:0.85rem;font-weight:700;color:var(--bg-dark);text-decoration:none;"
           id="nav-avatar-btn">?</a>
      </div>
      <button class="hamburger" id="hamburger" onclick="toggleMobileMenu()">
        <span></span><span></span><span></span>
      </button>
    </div>
  </nav>

  <!-- Mobile Menu -->
  <div class="mobile-menu" id="mobile-menu">
    <a href="index.html">🏠 Home</a>
    <a href="products.html?category=men">👔 Men</a>
    <a href="products.html?category=women">👗 Women</a>
    <a href="products.html?category=kids">🧒 Kids</a>
    <a href="products.html">🛍️ All Products</a>
    <a href="cart.html">🛒 My Cart</a>
    <a href="#" onclick="closeMobileMenu();openWishlistDrawer();">♥ My Wishlist</a>
    <a href="profile.html">👤 My Profile</a>
    <a href="login.html" id="mobile-login-link">🔐 Login / Register</a>
    <!-- Search in mobile -->
    <form onsubmit="navSearch(event)" style="display:flex;margin-top:0.5rem;">
      <input type="text" id="mobile-search-input" placeholder="Search products…"
             style="flex:1;background:var(--bg-card2);border:1px solid var(--border);color:var(--white);padding:8px 12px;border-radius:6px 0 0 6px;font-size:0.85rem;outline:none;font-family:var(--font-body);">
      <button type="submit" style="background:var(--accent);color:var(--bg-dark);border:none;padding:8px 12px;border-radius:0 6px 6px 0;cursor:pointer;font-size:0.9rem;">🔍</button>
    </form>
  </div>
  `;
}

// ---- Inject navbar into page ----
function initNavbar(activePage) {
  const placeholder = document.getElementById('navbar-placeholder');
  if (placeholder) placeholder.innerHTML = buildNavbar(activePage);
}

// ---- Search handler ----
function navSearch(e) {
  e.preventDefault();
  const q = (document.getElementById('nav-search-input')?.value ||
             document.getElementById('mobile-search-input')?.value || '').trim();
  if (q) window.location.href = `products.html?search=${encodeURIComponent(q)}`;
}

// ---- Mobile menu toggle ----
function toggleMobileMenu() {
  document.getElementById('mobile-menu')?.classList.toggle('open');
}
function closeMobileMenu() {
  document.getElementById('mobile-menu')?.classList.remove('open');
}

// ---- Update navbar user state after api.js loads ----
document.addEventListener('DOMContentLoaded', () => {
  const user = getUser && getUser();
  const loginBtn  = document.getElementById('nav-login-btn');
  const userMenu  = document.getElementById('nav-user-menu');
  const userName  = document.getElementById('nav-user-name');
  const avatarBtn = document.getElementById('nav-avatar-btn');
  const mobileLogin = document.getElementById('mobile-login-link');

  if (user && isLoggedIn && isLoggedIn()) {
    if (loginBtn) loginBtn.style.display = 'none';
    if (userMenu) userMenu.style.display = 'flex';
    if (userName) userName.textContent = user.name.split(' ')[0];
    if (avatarBtn) avatarBtn.textContent = user.name.charAt(0).toUpperCase();
    if (mobileLogin) mobileLogin.style.display = 'none';
  } else {
    if (loginBtn) loginBtn.style.display = 'inline-flex';
    if (userMenu) userMenu.style.display = 'none';
  }
});
