// ============================================================
// js/wishlist.js — Complete Wishlist System
// ============================================================
// Wishlist is stored in localStorage so it works without login.
// This file:
//   1. Manages wishlist data (add/remove/check)
//   2. Injects the side drawer HTML into every page
//   3. Updates all wishlist heart buttons on the page
//   4. Exposes global functions for other pages to use
// ============================================================

// ---- STORAGE KEY ----
const WL_KEY = 'trivora_wishlist';

// ---- Get wishlist array from localStorage ----
function wlGet() {
  try {
    return JSON.parse(localStorage.getItem(WL_KEY)) || [];
  } catch {
    return [];
  }
}

// ---- Save wishlist array to localStorage ----
function wlSave(list) {
  localStorage.setItem(WL_KEY, JSON.stringify(list));
}

// ---- Check if a product is in the wishlist ----
function wlHas(productId) {
  return wlGet().some(item => item._id === productId);
}

// ---- Add product to wishlist ----
function wlAdd(product) {
  const list = wlGet();
  if (!list.some(i => i._id === product._id)) {
    list.unshift(product); // Add to beginning
    wlSave(list);
  }
}

// ---- Remove product from wishlist ----
function wlRemove(productId) {
  const list = wlGet().filter(i => i._id !== productId);
  wlSave(list);
}

// ---- Toggle: add if not present, remove if present ----
function wlToggle(product) {
  if (wlHas(product._id)) {
    wlRemove(product._id);
    return false; // Was removed
  } else {
    wlAdd(product);
    return true;  // Was added
  }
}

// ---- Count of items in wishlist ----
function wlCount() {
  return wlGet().length;
}

// ============================================================
// DRAWER — inject HTML into page and wire up events
// ============================================================

function injectWishlistDrawer() {
  // Don't inject twice
  if (document.getElementById('wishlist-drawer')) return;

  const drawerHTML = `
    <!-- WISHLIST OVERLAY (backdrop) -->
    <div class="wishlist-overlay" id="wishlist-overlay" onclick="closeWishlistDrawer()"></div>

    <!-- WISHLIST DRAWER PANEL -->
    <div class="wishlist-drawer" id="wishlist-drawer" role="dialog" aria-label="Wishlist">

      <!-- Header -->
      <div class="wishlist-drawer-header">
        <h3 class="wishlist-drawer-title">
          ♥ My Wishlist
          <span class="wishlist-count-badge" id="wl-drawer-count">0</span>
        </h3>
        <button class="wishlist-drawer-close" onclick="closeWishlistDrawer()" title="Close">✕</button>
      </div>

      <!-- Items list -->
      <div class="wishlist-drawer-body" id="wl-drawer-body"></div>

      <!-- Footer (only shown when items exist) -->
      <div class="wishlist-drawer-footer" id="wl-drawer-footer" style="display:none;">
        <a href="wishlist.html" class="btn btn-outline btn-full btn-sm" onclick="closeWishlistDrawer()">
          View Full Wishlist →
        </a>
        <button class="btn btn-danger btn-full btn-sm" style="margin-top:0.6rem;" onclick="wlClearAll()">
          🗑️ Clear All
        </button>
      </div>
    </div>
  `;

  document.body.insertAdjacentHTML('beforeend', drawerHTML);

  // Close drawer on Escape key
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeWishlistDrawer();
  });
}

// ---- Open drawer ----
function openWishlistDrawer() {
  renderWishlistDrawer();
  document.getElementById('wishlist-drawer').classList.add('open');
  document.getElementById('wishlist-overlay').classList.add('open');
  document.body.style.overflow = 'hidden'; // Prevent page scroll
}

// ---- Close drawer ----
function closeWishlistDrawer() {
  document.getElementById('wishlist-drawer').classList.remove('open');
  document.getElementById('wishlist-overlay').classList.remove('open');
  document.body.style.overflow = '';
}

// ---- Render items inside the drawer ----
function renderWishlistDrawer() {
  const list = wlGet();
  const body = document.getElementById('wl-drawer-body');
  const footer = document.getElementById('wl-drawer-footer');
  const countBadge = document.getElementById('wl-drawer-count');

  countBadge.textContent = list.length;

  if (list.length === 0) {
    body.innerHTML = `
      <div class="wishlist-empty">
        <div class="wishlist-empty-icon">🤍</div>
        <h4>Your wishlist is empty</h4>
        <p style="font-size:0.85rem;margin-bottom:1.2rem;">Save items you love to buy them later</p>
        <a href="products.html" class="btn btn-primary btn-sm" onclick="closeWishlistDrawer()">
          Browse Products
        </a>
      </div>
    `;
    footer.style.display = 'none';
    return;
  }

  footer.style.display = 'block';

  body.innerHTML = list.map(product => {
    const discount = product.originalPrice
      ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
      : 0;
    return `
      <div class="wishlist-drawer-item" id="wl-item-${product._id}">
        <img class="wishlist-item-img" src="${product.image}" alt="${product.name}"
             onerror="this.src='https://picsum.photos/seed/${product._id}/200/250'"
             onclick="window.location.href='product-detail.html?id=${product._id}'; closeWishlistDrawer();">
        <div class="wishlist-item-info">
          <p class="wishlist-item-brand">${product.brand || 'Trivora'}</p>
          <p class="wishlist-item-name">${product.name}</p>
          <div style="display:flex;align-items:center;gap:0.4rem;margin-top:0.3rem;">
            <span class="wishlist-item-price">₹${product.price.toLocaleString('en-IN')}</span>
            ${discount > 0 ? `<span style="font-size:0.7rem;color:var(--green);font-weight:600;">${discount}% off</span>` : ''}
          </div>
        </div>
        <div class="wishlist-item-actions">
          <button class="wishlist-remove-btn" onclick="wlDrawerRemove('${product._id}')" title="Remove">✕</button>
          <button class="wishlist-cart-btn" onclick="wlMoveToCart('${product._id}')">🛒 Add</button>
        </div>
      </div>
    `;
  }).join('');
}

// ---- Remove item from drawer (with animation) ----
function wlDrawerRemove(productId) {
  const el = document.getElementById(`wl-item-${productId}`);
  if (el) {
    el.style.transition = 'all 0.3s ease';
    el.style.opacity = '0';
    el.style.transform = 'translateX(30px)';
    setTimeout(() => {
      wlRemove(productId);
      renderWishlistDrawer();
      updateWishlistNavBadge();
      // Update heart buttons on current page
      updateHeartButtons();
    }, 300);
  }
}

// ---- Move item from wishlist to cart ----
async function wlMoveToCart(productId) {
  if (!isLoggedIn()) {
    closeWishlistDrawer();
    showToast('Please login to add items to cart', 'error');
    setTimeout(() => window.location.href = 'login.html', 1500);
    return;
  }
  try {
    await api.addToCart({ productId, quantity: 1 });
    showToast('Added to cart! 🛒', 'success');
    updateCartBadge();
    // Optionally remove from wishlist
    wlRemove(productId);
    renderWishlistDrawer();
    updateWishlistNavBadge();
    updateHeartButtons();
  } catch (err) {
    showToast(err.message || 'Could not add to cart', 'error');
  }
}

// ---- Clear all wishlist items ----
function wlClearAll() {
  if (!confirm('Remove all items from wishlist?')) return;
  wlSave([]);
  renderWishlistDrawer();
  updateWishlistNavBadge();
  updateHeartButtons();
}

// ---- Update nav badge number ----
function updateWishlistNavBadge() {
  const badges = document.querySelectorAll('.wishlist-nav-count');
  const count = wlCount();
  badges.forEach(b => {
    b.textContent = count;
    b.style.display = count > 0 ? 'flex' : 'none';
  });
}

// ---- Toggle heart on product card (called from card buttons) ----
function toggleWishlistBtn(productId, productData, heartBtn) {
  const added = wlToggle(productData);
  if (added) {
    heartBtn.classList.add('wishlisted');
    heartBtn.textContent = '♥';
    showToast(`Added to wishlist ♥`, 'success');
  } else {
    heartBtn.classList.remove('wishlisted');
    heartBtn.textContent = '♡';
    showToast('Removed from wishlist', 'success');
  }
  updateWishlistNavBadge();
}

// ---- Update all heart buttons on page to reflect wishlist state ----
function updateHeartButtons() {
  document.querySelectorAll('[data-wl-id]').forEach(btn => {
    const id = btn.getAttribute('data-wl-id');
    if (wlHas(id)) {
      btn.classList.add('wishlisted');
      btn.textContent = '♥';
    } else {
      btn.classList.remove('wishlisted');
      btn.textContent = '♡';
    }
  });
}

// ============================================================
// INIT — runs on every page that includes this script
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
  injectWishlistDrawer();
  updateWishlistNavBadge();
});
